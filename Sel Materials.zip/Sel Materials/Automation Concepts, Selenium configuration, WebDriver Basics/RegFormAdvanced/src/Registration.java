import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import org.openqa.selenium.By;

public class Registration 
{
	static WebDriver driver;
	static String baseUrl; 
	
	public WebDriver setupDriver()
	{
		DriverSetup drSetup= new DriverSetup();
		driver=drSetup.getWebDriver();
	    //Assign the value for baseUrl
	    /* Get the driver, and launch the app using get() with baseUrl */
		baseUrl="http://webapps.tekstac.com/Shopify/";
		driver.get(baseUrl);
	     return driver;
	}
	
	public void setElements()
	{
	    /*Using the driver, Find the elements by id and send the values to the elements*/
       driver.findElement(By.id("firstname")).sendKeys("Mithali");
       driver.findElement(By.id("lastname")).sendKeys("Raj");
       driver.findElement(By.id("username")).sendKeys("Mithali Raj");
       driver.findElement(By.id("pass")).sendKeys("MR@123");
       Select s=new Select(driver.findElement(By.id("selectcity")));
    		   s.selectByValue("mas");
       WebElement gender= driver.findElement(By.xpath("//input[@value='female']"));
       gender.click();
       driver.findElement(By.id("reg")).click();
	}
	
	public static void main(String[] args)
	{
	    Registration reg=new Registration();
	    //Implement Code Here
	    reg.setupDriver();
	    reg.setElements();
	}

}
