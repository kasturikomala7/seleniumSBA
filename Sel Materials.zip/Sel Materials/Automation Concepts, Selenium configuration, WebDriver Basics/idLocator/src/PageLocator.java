import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;


//Add required imports

public class PageLocator    //DO NOT Change the class Name
{
	static WebDriver driver;
	public WebDriver createDriver()  //DO NOT change the method signature
	{
		DriverSetup drSetup= new DriverSetup();
		driver=drSetup.getWebDriver();
		driver.get("https://webapps.tekstac.com/Shopify/");
		return driver;
	   //Invoke getWebDriver method from DriverSetup and return it
	}
	
	public WebElement getPageLocator(WebDriver driver)  //DO NOT change the method signature
	{
	   /*Replace this comment by the code statement to get the WebElement of 'Lastname'*/
	   /*Find the element by id */
		WebElement lastName=driver.findElement(By.id("lastname"));
		return lastName;
    
	}
	public String getName(WebElement element)  //DO NOT change the method signature
	{
	    //Get the attribute value from the element and return it
		String lName= element.getAttribute("placeholder");
		return lName;
	}
	
	public static void main(String[] args){
	    PageLocator pl=new PageLocator();
	    //Add required code
	    pl.createDriver();
	    pl.getPageLocator(driver);
	    pl.getName(driver.findElement(By.id("lastname")));
	}

}
