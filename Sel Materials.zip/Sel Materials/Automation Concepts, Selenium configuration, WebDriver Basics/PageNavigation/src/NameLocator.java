import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;

public class NameLocator 
{
	static String page1, page2,page3,page4,page5,baseUrl;
	static WebDriver driver;

	
	public WebDriver setupDriver()
	{
		DriverSetup dSetup = new DriverSetup();
		driver=dSetup.getWebDriver();
		return driver;
	    /*Replace this comment by the code statement to get the driver*/
	    
	}
	public WebDriver navigate1() 
	{
	    /*Replace this comment by the code statement to navigate to baseUrl */
		baseUrl="https://www.selenium.dev/";
	    driver.navigate().to(baseUrl);
	    return driver;
	}
	public String getPageTitle1()
	{
	    /*Replace this comment by the code statement to get page title of  "https://selenium.dev/"*/
	    /* Assign the page title to variable 'page1' */
		page1=navigate1().getTitle();
		return page1;
	}
	public WebDriver navigate2()
	{
	    /*Replace this comment by the code statement to navigate to https://www.google.co.in/ */
		driver.navigate().to("https://www.google.co.in/");
		return driver;
	}
	public String getPageTitle2()
	{
	    /*Replace this comment by the code statement to get page title of  https://www.google.co.in/ */
	    /* Assign the page title to variable 'page2' */
		page2=navigate2().getTitle();
		return page2;
	}
	public WebDriver navigateBack()
	{
	    /*Replace this comment by the code statement to navigate back */
       driver.navigate().back();
       return driver;
	}
	public String getPageTitle3()
	{
	    /*Replace this comment by the code statement to get page title of backed page */
	    /* Assign the page title to variable 'page3' */
        page3=navigateBack().getTitle();
        return page3;
	}
	public WebDriver navigateForward()
	{
	    /*Replace this comment by the code statement to navigate forward */
        driver.navigate().forward();
        return driver;
	}
	public String getPageTitle4()
	{
	    /*Replace this comment by the code statement to get page title of the forwarded page */
	    /* Assign the page title to variable 'page4' */
		page4=navigateForward().getTitle();
		return page4;
	}
	public WebDriver refreshPage()
	{
	    /*Replace this comment by the code statement to refresh the page */
		driver.navigate().refresh();
        return driver;
	}
	public String getPageTitle5()
	{
	    /*Replace this comment by the code statement to get page title of refreshed page */
	    /* Assign the page title to variable 'page5' */
		page5=refreshPage().getTitle(); 
		return page5;
	}

	
	public static void main(String[] args)
	{
	    NameLocator namLocator=new NameLocator();
	    //Implement code here
	    namLocator.setupDriver();
	    namLocator.navigate1();
	    namLocator.getPageTitle1();
	    namLocator.navigate2();
	    namLocator.getPageTitle2();
	    namLocator.navigateBack();
	    namLocator.getPageTitle3();
	    namLocator.navigateForward();
	    namLocator.getPageTitle4();
	    namLocator.refreshPage();
	    namLocator.getPageTitle5();
	}

}

