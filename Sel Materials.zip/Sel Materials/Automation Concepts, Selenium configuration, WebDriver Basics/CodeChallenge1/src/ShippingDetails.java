import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class ShippingDetails {        //DO NOT change the class name
	
static WebDriver driver;
	
	public WebDriver createDriver()
	{
		DriverSetup drSetup=new DriverSetup();
		driver=drSetup.getWebDriver();
		return driver;
	   //Create driver, store in in static variable 'driver' and return it
	}
	
	public static void setNewFormValues(String shipmentid,String name,String departuredate,String arrivaldate)
	{
		//Find the form elements and set values by passing those values from 'main' method. 
	    //Submit form to add the details
		driver.findElement(By.id("shipmentid")).sendKeys(shipmentid);
		driver.findElement(By.id("name")).sendKeys(name);
		driver.findElement(By.id("departuredate")).sendKeys(departuredate);
		driver.findElement(By.id("arrivaldate")).sendKeys(arrivaldate);	
		driver.findElement(By.id("add")).click();
	}
	
	public static WebElement getNewShipmentId() {
		WebElement shipmentidrow= driver.findElement(By.xpath("//div[@id='result']/table/tbody/tr/td[1]"));
		return shipmentidrow;
		//Find and return the 'shipmentid' web element of the row displayed after first submit
		
	}
	public static WebElement getNewName() {
		WebElement namerow= driver.findElement(By.xpath("//div[@id='result']/table/tbody/tr/td[2]"));
		return namerow;
		//Find and return the 'name' web element of the row displayed after first submit
	}
	public static WebElement getNewdepartureDate() {
		WebElement departurerow= driver.findElement(By.xpath("//div[@id='result']/table/tbody/tr/td[3]"));
		return departurerow;
		//Find and return the 'departuredate' web element of the row displayed after first submit
	}
	public static WebElement getNewArrivalDate() {
		WebElement arrivalrow= driver.findElement(By.xpath("//div[@id='result']/table/tbody/tr/td[4]"));
		return arrivalrow;
		//Find and return the 'arrivaldate' web element of the row displayed after first submit
	}
	
	public static void editDetails() {
		//Find the first radio button and click 
	    //Find edit button and click
		driver.findElement(By.id("radio0")).click();
		driver.manage().window().maximize();
		driver.findElement(By.xpath("//button[@id='edit']")).click();
	}
	
	
	public static String getEditShipmentId() {
		String shipmentidvalue=driver.findElement(By.id("shipmentid")).getAttribute("value");		
		return shipmentidvalue;
		//Find and return the 'shipmentid' value in the edit box in the form after cicking edit
	}
	public static String getEditName() {
		String namevalue=driver.findElement(By.id("name")).getAttribute("value");		
		return namevalue;
		//Find and return the 'name' value in the edit box in the form after cicking edit
	}
	public static String EditNewDepartureDate() {
		String departurevalue=driver.findElement(By.id("departuredate")).getAttribute("value");		
		return departurevalue;
		//Find and return the 'departuredate' value in the edit box in the form after cicking edit
	}
	public static String getEditArrivalDate() {
		String arrivalvalue=driver.findElement(By.id("arrivaldate")).getAttribute("value");		
		return arrivalvalue;
		//Find and return the 'arrivaldate' value in the edit box in the form after cicking edit
	}
	
	
	public static void setUpdateFormValues(String shipmentid,String name,String departuredate,String arrivaldate)
	{
		//Set form values to update and submit (by passing those values from 'main' method). 
		driver.findElement(By.id("shipmentid")).clear();
		driver.findElement(By.id("name")).clear();
		driver.findElement(By.id("departuredate")).clear();
		driver.findElement(By.id("arrivaldate")).clear();
		getEditShipmentId();
		getEditName();
		EditNewDepartureDate();
		getEditArrivalDate();
		driver.findElement(By.id("shipmentid")).sendKeys(shipmentid);
		driver.findElement(By.id("name")).sendKeys(name);
		driver.findElement(By.id("departuredate")).sendKeys(departuredate);
		driver.findElement(By.id("arrivaldate")).sendKeys(arrivaldate);	
		driver.findElement(By.id("add")).click();
	}
	
	public static void deleteDetails() {
		//Find the SEaCOND row of address displayed and click the radio button
		//Find delete button and click to delete SECOND row
		driver.findElement(By.id("radio1")).click();
		driver.findElement(By.id("delete")).click();
	}
	
	public static void main(String[] args) {
		ShippingDetails ab=new ShippingDetails();
		//Add required code
		ab.createDriver();
		ab.setNewFormValues("NEW1234", "NewName", "01/01/2019", "02/01/2019");
		ab.setNewFormValues("SEC1234", "SECName", "02/01/2019", "04/01/2019");
		ab.setNewFormValues("THI1234", "THIName", "03/01/2019", "04/01/2019");
		ab.getNewShipmentId();
		ab.getNewName();
		ab.getNewdepartureDate();
		ab.getNewArrivalDate();
		ab.editDetails();
		ab.setUpdateFormValues("UPD1234", "UpdatedName", "03/01/2019", "04/01/2019");
		ab.deleteDetails();
		
	}
}
