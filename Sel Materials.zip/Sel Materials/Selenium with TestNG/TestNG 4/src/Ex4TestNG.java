import static org.junit.Assert.assertEquals;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.TestNG;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.collections.Lists;

import junit.framework.Assert;

@Listeners(FeatureTest.class) // DO NOT remove or alter this line. REQUIRED FOR
								// TESTING
public class Ex4TestNG // DO NOT Change the class Name
{
	WebDriver driver;
	XSSFSheet testSheet;
	static int testCount = 1;

	@BeforeSuite
	public void createDriver() { // DO NOT change the method signature
		DriverSetup dr = new DriverSetup();
		driver = dr.getWebDriver();
		// Create driver and assign it to 'static' driver variable
	}

	@DataProvider(name = "commodityData")
	public Object[][] commodityData() throws IOException {
		FileInputStream fo = null;
		fo = new FileInputStream(System.getProperty("user.dir") + "/CommodityDetails.xlsx");
		XSSFWorkbook workbook = new XSSFWorkbook(fo);
		XSSFSheet sheet = workbook.getSheetAt(0);

		long x2 = (long) sheet.getRow(1).getCell(1).getNumericCellValue();
		String weight1 = Long.toString(x2);

		long x3 = (long) sheet.getRow(1).getCell(2).getNumericCellValue();
		String length1 = Long.toString(x3);

		long x4 = (long) sheet.getRow(1).getCell(3).getNumericCellValue();
		String width1 = Long.toString(x4);

		long x5 = (long) sheet.getRow(1).getCell(4).getNumericCellValue();
		String height1 = Long.toString(x5);

		long x6 = (long) sheet.getRow(2).getCell(1).getNumericCellValue();
		String weight2 = Long.toString(x6);

		long x7 = (long) sheet.getRow(2).getCell(2).getNumericCellValue();
		String length2 = Long.toString(x7);

		long x8 = (long) sheet.getRow(2).getCell(3).getNumericCellValue();
		String width2 = Long.toString(x8);

		long x9 = (long) sheet.getRow(2).getCell(4).getNumericCellValue();
		String height2 = Long.toString(x9);

		return new Object[][] { { sheet.getRow(1).getCell(0).getStringCellValue(), weight1, length1, width1, height1 },
				{ sheet.getRow(2).getCell(0).getStringCellValue(), weight2, length2, width2, height2 } };

	}

	@Test(dataProvider = "commodityData")
	void testCommodity(String name, String weight, String length, String width, String height)
			throws InterruptedException {

		driver.findElement(By.id("name")).sendKeys(name);
		driver.findElement(By.id("weight")).sendKeys(weight);
		driver.findElement(By.id("length")).sendKeys(length);
		driver.findElement(By.id("width")).sendKeys(width);
		driver.findElement(By.id("height")).sendKeys(height);
		driver.findElement(By.id("add")).click();
		System.out.println(name + " starts....");
		Assert.assertEquals(name, driver.findElement(By.xpath("//table[@id='myTable']/tbody/tr[2]/td[1]")).getText());
		System.out.println("Expected: " + name + " is equal to "
				+ driver.findElement(By.xpath("//table[@id='myTable']/tbody/tr[2]/td[1]")).getText());

		Assert.assertEquals(weight, driver.findElement(By.xpath("//table[@id='myTable']/tbody/tr[2]/td[2]")).getText());
		System.out.println("Expected: " + weight + " is equal to "
				+ driver.findElement(By.xpath("//table[@id='myTable']/tbody/tr[2]/td[2]")).getText());

		Assert.assertEquals(length, driver.findElement(By.xpath("//table[@id='myTable']/tbody/tr[2]/td[3]")).getText());
		System.out.println("Expected: " + length + " is equal to "
				+ driver.findElement(By.xpath("//table[@id='myTable']/tbody/tr[2]/td[3]")).getText());

		Assert.assertEquals(width, driver.findElement(By.xpath("//table[@id='myTable']/tbody/tr[2]/td[4]")).getText());
		System.out.println("Expected: " + width + " is equal to "
				+ driver.findElement(By.xpath("//table[@id='myTable']/tbody/tr[2]/td[4]")).getText());

		Assert.assertEquals(height, driver.findElement(By.xpath("//table[@id='myTable']/tbody/tr[2]/td[5]")).getText());
		System.out.println("Expected: " + height + " is equal to "
				+ driver.findElement(By.xpath("//table[@id='myTable']/tbody/tr[2]/td[5]")).getText());
	}

	public void commodity() {
		// Invoke the test using TestNG ONLY HERE.
		TestNG testSuite = new TestNG();
		testSuite.setTestClasses(new Class[] { Ex4TestNG.class });
		testSuite.run();
	}

	public static void main(String[] args) {
		Ex4TestNG ex4 = new Ex4TestNG();
		// Implement any required code.
		ex4.commodity();
	}
}
