import static org.junit.Assert.assertEquals;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.*;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.util.SystemOutLogger;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.TestNG;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.collections.Lists;
import junit.framework.Assert;

@Listeners(FeatureTest.class)       //DO NOT remove or alter this line. REQUIRED FOR TESTING
public class Ex3TestNG               //DO NOT Change the class Name
{
	public static WebDriver driver;
	
	@BeforeSuite
	public void createDriver() {    //DO NOT change the method signature
		DriverSetup dr= new DriverSetup();
		driver=dr.getWebDriver();
		//Create driver and assign it to 'static' driver variable
    }
	@DataProvider(name = "shipmentData")
    public Object[][] shipmentData() throws IOException {
        FileInputStream fo = null;
        fo = new FileInputStream(System.getProperty("user.dir") + "/ShipmentDetails.xlsx");
        XSSFWorkbook workbook = new XSSFWorkbook(fo);
        XSSFSheet sheet = workbook.getSheetAt(0);
        String originPort=sheet.getRow(1).getCell(0).getStringCellValue();
        String destinationPort=sheet.getRow(1).getCell(1).getStringCellValue();
        
        long x3=(long)sheet.getRow(1).getCell(2).getNumericCellValue();
        String railModeCharge=Long.toString(x3);
       
        long x4=(long)sheet.getRow(1).getCell(3).getNumericCellValue();
        String roadModeCharge=Long.toString(x4);
       
        long x5=(long)sheet.getRow(1).getCell(4).getNumericCellValue();
        String airModeCharge=Long.toString(x5);

        String originPort1=sheet.getRow(2).getCell(0).getStringCellValue();
        String destinationPort2=sheet.getRow(2).getCell(1).getStringCellValue();
        
        long x6=(long)sheet.getRow(2).getCell(2).getNumericCellValue();
        String railModeCharge2=Long.toString(x6);
       
        long x7=(long)sheet.getRow(2).getCell(3).getNumericCellValue();
        String roadModeCharge2=Long.toString(x7);
       
        long x8=(long)sheet.getRow(2).getCell(4).getNumericCellValue();
        String airModeCharge2=Long.toString(x8);
        return new Object[][] {{originPort,destinationPort,railModeCharge,roadModeCharge,airModeCharge},
        	{originPort1,destinationPort2,railModeCharge2,roadModeCharge2,airModeCharge2}};
    }
		
		 
	//DO NOT change the method signature
	@Test(dataProvider = "shipmentData")
	void testShipment (String orginPort,String destinationPort,String railModeCharge,String roadModeCharge,String airModeCharge)	{
		
		Select s=new Select(driver.findElement(By.name("origin_id")));
		s.selectByVisibleText(orginPort);
		Select s1=new Select(driver.findElement(By.name("destination_id")));
		s1.selectByVisibleText(destinationPort);
		driver.findElement(By.xpath("//input[@name='submit']")).click();
		
		String rail= driver.findElement(By.xpath("//table[@name='charge']/tbody/tr[3]/td[2]")).getText();
		rail=rail.replace(".0", "");
		System.out.println(rail);
		String road= driver.findElement(By.xpath("//table[@name='charge']/tbody/tr[2]/td[2]")).getText();
	    road=road.replace(".0", "");
		System.out.println(road);
		String air= driver.findElement(By.xpath("//table[@name='charge']/tbody/tr[4]/td[2]")).getText();
		air=air.replace(".0", "");
		System.out.println(air);
		
		try {
			Assert.assertEquals(railModeCharge, rail);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println("The Rail mode Charge doesnt match");
		}
		
		try {
			Assert.assertEquals(roadModeCharge, road);
		} catch (Exception e) {
			System.out.println("The Road mode Charge doesnt match");
		}
		
		try {
			Assert.assertEquals(airModeCharge, air);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println("The Air mode Charge doesnt match");
		}
		
		//Select the souce/destination as specified in description.
		// Test the tabled data against the excel data as specified in description.
	}
	
	public  void shipment() {
		
		TestNG testSuite= new TestNG();
		testSuite.setTestClasses(new Class[]{Ex3TestNG.class});
		testSuite.run();
	    //Invoke the test using TestNG ONLY HERE.
	}
	
	public static void main(String[] args) throws InterruptedException, IOException {
		Ex3TestNG ex3=new Ex3TestNG();
	    //Implement any required code. 
		
		ex3.shipment();
		
	}
}
	
	
	


