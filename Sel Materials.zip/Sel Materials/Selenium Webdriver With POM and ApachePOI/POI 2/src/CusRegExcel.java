import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.ss.usermodel.*;

public class CusRegExcel { // DO NOT change the class name

	// Wrire the below values into excel sheet. DO NOT change the values
	static String[] fields1 = new String[] { "Tester", "32", "XYZ", "2323245235", "test1@gmail.com" };
	static String[] fields2 = new String[] { "Tester1", "33", "ABC", "4323245125", "test2@gmail.com" };
	static String[] fields3 = new String[] { "Tester2", "34", "KLM", "1323245235", "test3@gmail.com" };

	public static String getExcelPath(String sheetName) { // DO NOT change the
															// method signature
		// Implement code to locate excelsheet.
		File fileObj = new File("CustReg.xlsx");
		String dirPath = fileObj.getAbsolutePath();
		System.out.println(dirPath);

		// Implement code to locate the excel file. Return the filepath
		return dirPath;
		// Return the filepath
	}

	public static void writeExcelData(String sheetName) { // DO NOT change the
															// method signature
		// Implement code to write the given fields1,fields2,fields3 data to
		// excel sheet.
		try {
			FileInputStream fi = null;
			fi = new FileInputStream("CustReg.xlsx");
			Workbook workbook = WorkbookFactory.create(fi);
			Sheet sheet = workbook.getSheetAt(0);
			Row row1 = sheet.createRow(2);
			Row row2 = sheet.createRow(3);
			Row row3 = sheet.createRow(4);
			for (int i = 0; i < 5; i++) {
				if (i == 1 || i == 3) {
					Long value1 = Long.valueOf(fields1[i]);
					row1.createCell(i).setCellValue(value1);
					Long value2 = Long.valueOf(fields2[i]);
					row2.createCell(i).setCellValue(value2);
					Long value3 = Long.valueOf(fields3[i]);
					row3.createCell(i).setCellValue(value3);
				} else {
					row1.createCell(i).setCellValue(fields1[i]);
					row2.createCell(i).setCellValue(fields2[i]);
					row3.createCell(i).setCellValue(fields3[i]);
				}
			}

			FileOutputStream out = new FileOutputStream(new File("CustReg.xlsx"));
			workbook.write(out);
			workbook.close();
			out.close();
			System.out.println("File written successfully...");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) throws Exception {
		CusRegExcel customer = new CusRegExcel();
		// Add required code
		String pathFile = customer.getExcelPath("CustReg.xlsx");
		customer.writeExcelData("CustReg.xlsx");

	}
}
