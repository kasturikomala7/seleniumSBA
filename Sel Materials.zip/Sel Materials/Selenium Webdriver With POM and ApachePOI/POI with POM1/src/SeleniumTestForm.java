import java.util.regex.Pattern;
import java.util.concurrent.TimeUnit;
import org.junit.*;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;
import java.io.IOException;

public class SeleniumTestForm {      //Do not change the class name

    public static WebDriver driver;
    
    
    public void createDriver() {                //Do not change the method signature
    	DriverSetup dr=new DriverSetup();
    	driver=dr.getWebDriver();
        //Implement code to create driver and assign it to 'static' driver variable	
    }

    public void testSeleniumTestForm() throws IOException {    //Do not change the method signature
    	String[] customer1=new String[5];
    	CusRegExcel customer = new CusRegExcel();
	    //Add required code
    	customer1=customer.readExcelData("CustReg.xlsx");
    	//Read the data from excel sheet. Sheet name is 'customervalid'
       //find the elements in the form and set values parsed from excel sheet. Submit the form for registration
    	driver.findElement(By.xpath("//input[@name='cname']")).sendKeys(customer1[0]);
    	driver.findElement(By.xpath("//input[@name='age']")).sendKeys(customer1[1]);
    	driver.findElement(By.xpath("//input[@name='address']")).sendKeys(customer1[2]);
    	driver.findElement(By.xpath("//input[@name='phonenumber']")).sendKeys(customer1[3]);
    	driver.findElement(By.xpath("//input[@name='email']")).sendKeys(customer1[4]);
    	driver.findElement(By.xpath("//input[@id='submit']")).click();   	
    }
    public void closeBrowser(){
    	driver.close();
        //close the browser
    }

    public static void main(String[] args) throws Exception 
	{ 
	    CusRegExcel customer = new CusRegExcel();
	    //Add required code
	    customer.readExcelData("CustReg.xlsx");
	    
	    SeleniumTestForm stf=new SeleniumTestForm();
	    stf.createDriver();
	    stf.testSeleniumTestForm();
	    stf.closeBrowser();
	    
	   
	    
	    
	}
}
   