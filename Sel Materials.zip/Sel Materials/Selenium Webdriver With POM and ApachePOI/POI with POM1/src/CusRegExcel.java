import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.ss.usermodel.*;
import java.io.IOException;
import java.util.Arrays;
import java.util.Iterator;

public class CusRegExcel {         //Do not change the class name
	
	//Use this declaration to store values parsed from excel
    public static String[] customerData=new String[5];
    
    public static String[] readExcelData(String fileName) throws IOException{ //Do not change the method signature
    	
    	File file = new File(fileName);
    	FileInputStream fis= new FileInputStream(file);
    	XSSFWorkbook workbook= new XSSFWorkbook(fis);
    	XSSFSheet sheet= workbook.getSheetAt(0);
    	
    	customerData[0]=sheet.getRow(0).getCell(0).getStringCellValue();
    	int a1=(int) sheet.getRow(0).getCell(1).getNumericCellValue();
    	customerData[1]=Integer.toString(a1);
    	customerData[2]=sheet.getRow(0).getCell(2).getStringCellValue();
    	int a2=(int) sheet.getRow(0).getCell(3).getNumericCellValue();
    	customerData[3]=Integer.toString(a2);
    	customerData[4]=sheet.getRow(0).getCell(4).getStringCellValue();
    	
		return customerData;
 
    	
        //Implement code to read data from excel file. Store the values in 'customerData' array. Return the array. */

    }
    


}

  