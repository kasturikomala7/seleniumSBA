import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Iterator;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.ss.usermodel.*;

public class CusRegExcel { // Do NOT change the class name

	public static Object[][] readExcelData(String sheetName) throws IOException {
		FileInputStream fo=null;
		fo=new FileInputStream("CustReg.xlsx");

		XSSFWorkbook workbook=new XSSFWorkbook(fo);
		XSSFSheet sheet=workbook.getSheetAt(0);
		int getRows=sheet.getLastRowNum();
		int getColumns=sheet.getRow(0).getLastCellNum();
		Object value[][]=new Object[getRows+1][getColumns];
		for(int i=0;i<=getRows;i++)
		 {
		 for(int j=0;j<sheet.getRow(i).getLastCellNum();j++)
		 {
		 XSSFCell cell=sheet.getRow(i).getCell(j);
		 switch(cell.getCellType()) {
		 case XSSFCell.CELL_TYPE_STRING:
		 value[i][j]=sheet.getRow(i).getCell(j).getStringCellValue();
		 break;
		 case XSSFCell.CELL_TYPE_NUMERIC:
		 long x=(long)sheet.getRow(i).getCell(j).getNumericCellValue();
		 value[i][j]=Long.toString(x);
		 break;
		 default:
		 }
		 
		 System.out.print(value[i][j]+" ");
		 }
		 System.out.println();
		 }
		 return value;
	}


	public static String getExcelPath(String sheetName) 
    {
    	File fileObj = new File("CustReg.xlsx");
    	String dirPath = fileObj.getAbsolutePath();
    			//.getAbsolutePath();
    	System.out.println(dirPath);
    	
	    //Implement code to locate the excel file. Return the filepath
		return dirPath;
    }

	public static void main(String[] args) throws Exception 
	{ 
	    CusRegExcel customer = new CusRegExcel();
	    //Add required code
	    String filepathName= customer.getExcelPath("CustReg.xlsx");
	    
	    customer.readExcelData(System.getProperty("user.dir") + "/CustReg.xlsx");

	}
}
