import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

//Add required imports

public class CSSLocator     //DO NOT change the class name
{
	static WebDriver driver;
	public WebDriver createDriver()  //DO NOT change the method signature
	{
	   //Implement code to create Driver from DriverSetup and return it
	   DriverSetup drSet = new DriverSetup();
	   driver=drSet.getWebDriver();
	   return driver;
	}
	
	public WebElement getCSSLocator(WebDriver driver)  //DO NOT change the method signature
	{
	   /*Replace this comment by the code statement to get the Web element of username*/
	   /*Find and return the element */ 
       WebElement usrname= driver.findElement(By.cssSelector("input#username"));
       return usrname;
	}
	
	public String getName(WebElement element)  //DO NOT change the method signature
	{
	    //Get the attribute value from the element and return it
	    String fname=element.getAttribute("placeholder");
	    return fname;
	}
	
    public static void main(String[] args){
	    CSSLocator pl=new CSSLocator();
	    //Add required code
	    pl.createDriver();
	    pl.getCSSLocator(driver);
	    String name=pl.getName(driver.findElement(By.cssSelector("input#username")));
	    System.out.println(name);
	}
}

