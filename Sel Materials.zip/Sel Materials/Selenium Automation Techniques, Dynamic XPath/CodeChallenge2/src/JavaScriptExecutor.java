import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;


public class JavaScriptExecutor{                    //DO NOT Change the class name
	
	public WebDriver driver;
	public String Url = "http://webapps.tekstac.com/Cargo_Shipping_Cost/";

	
	public WebDriver createDriver()  //DO NOT Change the method Signature
	{
		DriverSetup drSetup=new DriverSetup();
		driver=drSetup.getWebDriver();
		driver.get(Url);
		return driver;
	    /* Replace this comment by the code statement to create and return the driver */
	    /* Naviaget to the Url  */
	    
	}
 
  public String submitForm(String weight,String mode) 
  {
	JavascriptExecutor js=(JavascriptExecutor) driver;
	js.executeScript("document.getElementById('weight').value='"+weight+"';");
	js.executeScript("document.getElementById('"+mode+"').click()");
	js.executeScript("document.getElementById('calculate').click()");
	String result=js.executeScript("return document.getElementById('result').innerHTML").toString();
	driver.close();
	System.out.println(result);
	return result;
	
      /*Using the driver, Locate the element using javascript executor ONLY. */
      /* Set the form values and submit */
      /* Return the displayed message */
       /*Close the driver*/
       
  }
  public static void main(String[] args) {
	  JavaScriptExecutor at=new JavaScriptExecutor();
	 //Add required code
	  at.createDriver();
	  at.submitForm("70","air" );
  }
  
}