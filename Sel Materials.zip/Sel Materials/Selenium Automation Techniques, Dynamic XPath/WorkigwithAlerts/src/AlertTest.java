
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;



import java.util.concurrent.TimeUnit;
import org.openqa.selenium.Alert;

public class AlertTest    //DO NOT Change the class Name
{
	public static WebDriver driver;
	public WebDriver createDriver()  //DO NOT change the method signature
	{
		DriverSetup drSetup=new DriverSetup();
		driver=drSetup.getWebDriver();
		return driver;
	   //Implement code to create Driver from DriverSetup, assign it to 'static' variable and return it

	}
	
	public Alert getAlertElement(WebDriver driver)   //DO NOT change the method signature
	{
		
		driver.findElement(By.xpath("//input[@name='submit']")).click();
		Alert alert=driver.switchTo().alert();
		//alert.accept();
		return alert;
	    //Find the 'click' buttton and click it.
	    //Locate the 'Alert' element and return it
	    
	}

	public static void main(String[] args)  throws InterruptedException  //DO NOT change the method signature
	{      
	    AlertTest at=new AlertTest();
	    //Implement code here
	    at.createDriver();
	    Alert message=at.getAlertElement(driver);
	    System.out.println(message);

	}

}



