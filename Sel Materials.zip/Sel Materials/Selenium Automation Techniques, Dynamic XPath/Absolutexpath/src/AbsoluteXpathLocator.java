import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;



//Add required imports

public class AbsoluteXpathLocator  //DO NOT Change the class Name
{
	static WebDriver driver;
	public WebDriver createDriver()
	{
		DriverSetup drSetup=new DriverSetup();
		driver=drSetup.getWebDriver();
		return driver;
	   //Implement code to create Driver from DriverSetup and return it
	}
	public WebElement getAbsoluteXpathLocator(WebDriver driver)//DO NOT change the method signature
	{
	   /*Replace this comment by the code statement to get the Web element of logo */
	   /*Find and return the element */ 
		WebElement logo=driver.findElement(By.xpath("/html/body/form/div/img"));
		return logo;    
	}
	public String getName(WebElement element)    //DO NOT change the method signature
	{
	    //Get the attribute value from the element and return it
		String logoName=element.getAttribute("src");
		return logoName;
	}

    public static void main(String[] args){
	    AbsoluteXpathLocator pl=new AbsoluteXpathLocator();
	   //Add required code 
	    pl.createDriver();
	    pl.getAbsoluteXpathLocator(driver);
	    String srcName=pl.getName(driver.findElement(By.xpath("/html/body/form/div/img")));
	    System.out.println("src name" + srcName);
	    
	}
}
