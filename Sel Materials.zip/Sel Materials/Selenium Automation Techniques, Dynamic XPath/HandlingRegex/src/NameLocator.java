import org.openqa.selenium.WebDriver;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;




public class NameLocator {      //DO NOT change the class name
	 
    public static String baseUrl; //Assign 'http://webapps.tekstac.com/Handling_Regular_Expression/' for baseUrl
    public static WebDriver driver;
	
	public WebDriver createDriver()
	{
		DriverSetup drSetup=new DriverSetup();
		driver=drSetup.getWebDriver();
		return driver;
	    //Create driver. Assign it to static variable 'driver' and return it
	}
	
	public void navigate(WebDriver driver){
	     //Navigate to the baseUrl
		baseUrl="http://webapps.tekstac.com/Handling_Regular_Expression/";
		driver.get(baseUrl);
	}
	
   	public void setFormValues(WebDriver driver)
	{
   		driver.findElement(By.id("userId")).sendKeys("Shamili");
   		driver.findElement(By.id("track")).click();
	    //set the value for 'Shipment for user' and submit form
	}

   	public WebElement getNameResultElement(WebDriver driver) {
    	WebElement result =driver.findElement(By.xpath("//*[text()='Shamili']"));
		return result;
        //Find the element of 'Shamili' and return it
        
    }
    public WebElement getShipmentResultElement(WebDriver driver) {
    	WebElement resultShip =driver.findElement(By.xpath("//div[@id='shipment']"));
		return resultShip;
         //Find the element of 'SHIP1236' and return it
    }
    public WebElement getEmailResultElement(WebDriver driver) {
    	WebElement resultemail =driver.findElement(By.xpath("//div[@id='e- mail']"));
		return resultemail;
        
        //Find the element of 'shamili93@gamil.com' and return it
    }
    
    public boolean validateEmail(String eMailID) {
    	Pattern pattern= Pattern.compile("\\b[A-Z0-9a-z-]+@[a-z]+\\.[a-z]{2,4}\\b");
    	Matcher matcher=pattern.matcher(eMailID);
		return matcher.matches();
       //Validate email using regex. 
        
    }
    public boolean validateShipmentId(String shipmentId) {
    	Pattern pattern= Pattern.compile("[A-Z0-9]{8}");
    	Matcher matcher=pattern.matcher(shipmentId);
		return matcher.matches();
        //Validate shipmentId using regex
        
    }    
        
        
       
  
    public static void main(String[] args)
	{
	    NameLocator reg=new NameLocator();
	     //Add required code here
	    reg.createDriver();
	    reg.navigate(driver);
	    reg.setFormValues(driver);
	    reg.getNameResultElement(driver);
	    reg.getShipmentResultElement(driver);
	    reg.getEmailResultElement(driver);
        String emailID=driver.findElement(By.xpath("//div[@id='e- mail']")).getText();
        String shipmentID=driver.findElement(By.xpath("//div[@id='shipment']")).getText();
	    boolean tt1=reg.validateEmail(emailID);
	    System.out.println(tt1);
	    boolean tt2=reg.validateShipmentId(shipmentID);
	    System.out.println(tt2);
	}
}


