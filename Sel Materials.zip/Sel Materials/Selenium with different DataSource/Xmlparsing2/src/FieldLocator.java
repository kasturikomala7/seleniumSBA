import org.openqa.selenium.WebDriver;
import org.openqa.selenium.By;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.File;
import java.io.IOException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class FieldLocator { // DO NOT Change the class Name

	public static WebDriver driver;
	Element eElement;

	public void createDriver() // DO NOT change the method signature
	{
		// Implement code to create Driver from DriverSetup, set to 'static'
		// driver variable and return it
		DriverSetup dr = new DriverSetup();
		driver = dr.getWebDriver();
	}

	public Element ReadFile(String xmlfileName, String id) throws SAXException, IOException, ParserConfigurationException {
		// Implement code to read and return XPath object reference
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
		Document doc = dBuilder.parse(xmlfileName);
		NodeList nList = doc.getElementsByTagName("Customer");
		for (int itr = 0; itr < nList.getLength(); itr++) {
			Node node = nList.item(itr);
			System.out.println("\nNode Name :" + node.getNodeName());
			if (node.getNodeType() == Node.ELEMENT_NODE) {
				eElement = (Element) node;
				String customerName = getCustomerName(Integer.parseInt(id));
				String Invoicenumber = getInvoiceNumber(Integer.parseInt(id));
				String Amount = getAmount(Integer.parseInt(id));
				String Mobilenumber = getMobileNumber(Integer.parseInt(id));
			}
		}
		return eElement;
	}

	public String getCustomerName(int id) {
		// Implement code to return customername from xml
		return eElement.getElementsByTagName("Customername").item(id - 1).getTextContent();
	}

	public String getInvoiceNumber(int id) {
		// Implement code to return invoicenumber from xml
		return eElement.getElementsByTagName("Invoicenumber").item(id - 1).getTextContent();
	}

	public String getAmount(int id) {
		// Implement code to return amount from xml
		return eElement.getElementsByTagName("Amount").item(id - 1).getTextContent();
	}

	public String getMobileNumber(int id) {
		// Implement code to return phone number from xml
		return eElement.getElementsByTagName("Mobilenumber").item(id - 1).getTextContent();
	}

	public String getMessage(String customerName, String invoiceNumber, String amount, String mobileNumber) {
		// Implement code to submit form with values got from xml and return the
		// success message printed on the page.
		driver.findElement(By.id("name")).sendKeys(customerName);
		driver.findElement(By.id("number")).sendKeys(invoiceNumber);
		driver.findElement(By.name("amount")).sendKeys(amount);
		driver.findElement(By.name("num")).sendKeys(mobileNumber);
		driver.findElement(By.id("submit")).click();
		String message = driver.findElement(By.xpath("//div[@id='result']")).getText();
		return message;
	}

	public static void main(String[] args) throws SAXException, IOException, ParserConfigurationException {
		FieldLocator pagLocator = new FieldLocator();
		pagLocator.createDriver();

		pagLocator.ReadFile("C:\\Users\\516403\\workspace\\ZXmlparse\\src\\CustomerDetails.xml", "1");
		// Implement the required code
		String customerName = pagLocator.getCustomerName(1);
		String invoiceNumber = pagLocator.getInvoiceNumber(1);
		String amount = pagLocator.getAmount(1);
		String mobileNumber = pagLocator.getMobileNumber(1);
		pagLocator.getMessage(customerName, invoiceNumber, amount, mobileNumber);
		// Close the driver
		driver.close();
	}

}