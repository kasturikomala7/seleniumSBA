import org.openqa.selenium.WebDriver;


import org.openqa.selenium.By;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Iterator;
import java.util.Map;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class NameLocator //DO NOT Change the class Name
{
	JSONArray address;
	public static WebDriver driver;
	
	public void createDriver() //DO NOT change the method signature
	{
		DriverSetup dr=new DriverSetup();
		driver=dr.getWebDriver();
	   //Implement code to create Driver from DriverSetup and set to 'static' driver variable
	}
	
	public JSONArray ReadFile(String fileName) throws FileNotFoundException, IOException, ParseException   //DO NOT change the method signature
    {
		JSONParser parser=new JSONParser();
		Object obj= parser.parse(new FileReader(fileName));
		JSONObject jobj=(JSONObject) obj;
		address= (JSONArray) jobj.get("Agents");
		System.out.println(address);
		return address;
        //Implement code to read and return agents as JSON array 
    }
    public String getFirstName(int id) {
    	JSONObject item = (JSONObject)address.get(id-1);
        String FirstName = (String)item.get("FirstName");
        System.out.println(FirstName);
        return FirstName;
		//Implement code to return firstname from agent
	}

	public String getLastName(int id) {
		JSONObject item = (JSONObject)address.get(id-1);
        String LastName = (String)item.get("LastName");
        System.out.println(LastName);
        return LastName;
		//Implement code to return lastname from agent
	}

	public String getUserName(int id) {
		JSONObject item = (JSONObject)address.get(id-1);
        String UserName = (String)item.get("UserName");
        System.out.println(UserName);
        return UserName;
	//Implement code to return username from agent
	}

	public String getPhoneNumber(int id) {
		JSONObject item = (JSONObject)address.get(id-1);
        String PhoneNumber = (String)item.get("PhoneNumber");
        System.out.println(PhoneNumber);
        return PhoneNumber;
		//Implement code to return phonenumber from agent
	}
	
	public String getPassword(int id) {
		JSONObject item = (JSONObject)address.get(id-1);
        String Password = (String)item.get("Password");
        System.out.println(Password);
        return Password;
		//Implement code to return password from agent
	}
	
	
	public String getEmail(int id) {
		JSONObject item = (JSONObject)address.get(id-1);
        String Email = (String)item.get("Email");
        System.out.println(Email);
        return Email;
		//Implement code to return email from agent
	}
	

	public String getMessage(WebDriver driver, String firstname, String lastname, String username,String password,String phone, String email) throws InterruptedException {
		driver.findElement(By.xpath("//input[@name='firstname']")).sendKeys(firstname);
		driver.findElement(By.xpath("//input[@name='lastname']")).sendKeys(lastname);
		driver.findElement(By.xpath("//input[@name='username']")).sendKeys(username);
		driver.findElement(By.xpath("//input[@name='password']")).sendKeys(password);
		driver.findElement(By.xpath("//input[@name='phonenumber']")).sendKeys(phone);
		driver.findElement(By.xpath("//input[@name='email']")).sendKeys(email);
		
		driver.findElement(By.xpath("//input[@id='submit']")).click();
		Thread.sleep(3000);
		String message= driver.findElement(By.xpath("//h2[text()='Registered Succesfully']")).getText();
		//Implement code to submit form with values got from json and return the success message printed on the page.
		return message;
	}

	public static void main(String[] args) throws FileNotFoundException, IOException, ParseException, InterruptedException {
		NameLocator nameLocator = new NameLocator();
		nameLocator.createDriver();
		nameLocator.ReadFile("C:\\Users\\516403\\workspace\\ttttstt\\src\\ttttstt\\AgentDetail.json");
		String fname= nameLocator.getFirstName(0);
		System.out.println(fname);
		String lname=nameLocator.getLastName(0);
		System.out.println(lname);
	 	String uname=nameLocator.getUserName(0);
	 	System.out.println(uname);
		String pass=nameLocator.getPassword(0);
		System.out.println(pass);
		String phonenum=nameLocator.getPhoneNumber(0);
		System.out.println(phonenum);
		String emailid=nameLocator.getEmail(0);
		System.out.println(emailid);
		nameLocator.getMessage(driver,fname,lname,uname,pass,phonenum,emailid);
		driver.close();
		//Implement the required code
	    //Close the driver
	}

}

