import org.openqa.selenium.WebDriver;


import org.openqa.selenium.By;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Iterator;
import java.util.Map;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;


	public class FieldLocator //DO NOT Change the class Name
	{
		static JSONArray address;
		public static WebDriver driver;
		
		public void createDriver() //DO NOT change the method signature
		{
			DriverSetup dr=new DriverSetup();
			driver=dr.getWebDriver();
		   //Implement code to create Driver from DriverSetup and set to 'static' driver variable
		}
		
		public JSONArray ReadFile(String fileName) throws FileNotFoundException, IOException, ParseException   //DO NOT change the method signature
	    {
	        //Implement code to read and return addresses as JSON array 
			JSONParser parser=new JSONParser();
			Object obj= parser.parse(new FileReader(fileName));
			JSONObject jobj=(JSONObject) obj;
			address= (JSONArray) jobj.get("Addresses");
			System.out.println(address);
			return address;
	    }
	    
	    public String getNickName(int id) {
	    	JSONObject item = (JSONObject)address.get(id-1);
	        String NickName = (String)item.get("NickName");
	        System.out.println(NickName);
	        return NickName;
	        //Implement code to return nickname from address
	    }

		public String getContactName(int id) {
			JSONObject item = (JSONObject)address.get(id-1);
	        String NickName = (String)item.get("ContactName");
	        System.out.println(NickName);
	        return NickName;
			//Implement code to return contactname from address
		}

		public String getCity(int id) {
			JSONObject item = (JSONObject)address.get(id-1);
	        String NickName = (String)item.get("City");
	        System.out.println(NickName);
	        return NickName;
			//Implement code to return city from address
		}

		public String getType(int id) {
			JSONObject item = (JSONObject)address.get(id-1);
	        String NickName = (String)item.get("Type");
	        System.out.println(NickName);
	        return NickName;
			//Implement code to return type from address
		}

		public void getMessage(WebDriver driver,String nname, String cname, String ccity, String ttype) {
			driver.findElement(By.xpath("//input[@id='nickname']")).sendKeys(nname);
			driver.findElement(By.xpath("//input[@id='contact']")).sendKeys(cname);
			driver.findElement(By.xpath("//input[@id='city']")).sendKeys(ccity);
			driver.findElement(By.xpath("//input[@id='type']")).sendKeys(ttype);
			driver.findElement(By.xpath("//button[@id='add']")).click();

			//Implement code to submit form with values got from json and return the success message printed on the page.
		}

		public static void main(String[] args) throws FileNotFoundException, IOException, ParseException {
			FieldLocator pagLocator=new FieldLocator();
			pagLocator.createDriver();
			pagLocator.ReadFile("C:\\Users\\516403\\workspace\\ttttstt\\src\\ttttstt\\AddressBook.json");
					
			JSONObject item1 = (JSONObject)address.get(0);
	        String str1 = (String)item1.get("id");
	        int id1=Integer.parseInt(str1);
	        JSONObject item2 = (JSONObject)address.get(1);
	        String str2 = (String)item2.get("id");
	        int id2=Integer.parseInt(str2);
	        
	        String nick= pagLocator.getNickName(id1);
			System.out.println(nick);
			String contact=pagLocator.getContactName(id1);
			System.out.println(contact);
		 	String city=pagLocator.getCity(id1);
		 	System.out.println(city);
			String type=pagLocator.getType(id1);
			System.out.println(type);
			pagLocator.getMessage(driver,nick,contact,city,type);
			driver.close();
					
		   //Implement the required code
		    //Close the driver
		}

	}

