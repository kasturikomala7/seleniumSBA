import org.openqa.selenium.WebDriver;
import org.apache.xmlbeans.impl.xb.xsdschema.FieldDocument.Field.Xpath;
import org.openqa.selenium.By;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.File;
import java.io.IOException;

import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;


public class NameLocator   //DO NOT Change the class Name
{
	
	public static WebDriver driver;
	public static XPath xpath;
	public static Element eElement1;
	
	public WebDriver createDriver() //DO NOT change the method signature
	{
		DriverSetup dr=new DriverSetup();
		driver=dr.getWebDriver();
		return driver;
	   //Implement code to create Driver from DriverSetup, set to 'static' driver variable and return it
	}
	
	public XPath ReadFile(String xmlfileName,String id) throws ParserConfigurationException, SAXException, IOException
    {
		String projectPath=System.getProperty("user.dir");
		File fXmlFile = new File(projectPath+File.separator+xmlfileName);
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
		Document doc = dBuilder.parse(fXmlFile);
		xpath =  XPathFactory.newInstance().newXPath();
	
		NodeList nList = doc.getElementsByTagName("User");
		for (int itr = 0; itr < nList.getLength(); itr++) {
			Node node = nList.item(itr);
			System.out.println("\nNode Name :" + node.getNodeName());
			if (node.getNodeType() == Node.ELEMENT_NODE) {
				eElement1 = (Element) node;
				String firstName = getFirstName(Integer.parseInt(id));
				String lastName = getLastName(Integer.parseInt(id));
				String userName = getUserName(Integer.parseInt(id));
				String pssword = getPassword(Integer.parseInt(id));
			}
		}
		return xpath;
	} 
        //Implement code to read and assign the XPath object reference to xpath static variable

    public  String getFirstName(int id){
    	//Element pageObject= xpath.item(id);
    	return eElement1.getElementsByTagName("Firstname").item(id-1).getTextContent();
        //Implement code to return firstname from xml    
    }
    public  String getLastName(int id){
    	return eElement1.getElementsByTagName("Lastname").item(id-1).getTextContent();
        //Implement code to return lastname from xml
    }
    public  String getUserName(int id){
    	return eElement1.getElementsByTagName("Username").item(id-1).getTextContent();
        //Implement code to return username from xml
    }
    
    public  String getPassword(int id){
    	return eElement1.getElementsByTagName("Password").item(id-1).getTextContent();
        //Implement code to return passworf from xml
    }
        
      public  String  getMessage(String firstName, String lastName,String userName,String password){
    	driver.findElement(By.id("firstname")).sendKeys(firstName);
  		driver.findElement(By.id("lastname")).sendKeys(lastName);
  		driver.findElement(By.id("username")).sendKeys(userName);
  		driver.findElement(By.id("pass")).sendKeys(password);
  		driver.findElement(By.id("reg")).click();
  		String message = "Registered Successfully";
  		return message;
  	}
        //Implement code to submit form with values got from xml and return the success message printed on the page.

      public static void main(String[] args) throws ParserConfigurationException, SAXException, IOException
	{
	    NameLocator pagLocator=new NameLocator();
	   //Implement the required code
	    //Close the driver
	    pagLocator.createDriver();
	    pagLocator.ReadFile("Userdetails.xml", "1");
	    String firstName = pagLocator.getFirstName(1);
		String lastName = pagLocator.getLastName(1);
		String userName = pagLocator.getUserName(1);
		String password = pagLocator.getPassword(1);
		pagLocator.getMessage(firstName,lastName,userName,password);
	    driver.close();
	}

}

